A Pen created at CodePen.io. You can find this one at https://codepen.io/eliedim/pen/jZxdqy.

 This is checkmark svg animation that draws itself when you click the button. It is animation very useful for situation when you need to add product in the cart of your site for example.